<?php

namespace MiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MiBundle extends Bundle
{
}
