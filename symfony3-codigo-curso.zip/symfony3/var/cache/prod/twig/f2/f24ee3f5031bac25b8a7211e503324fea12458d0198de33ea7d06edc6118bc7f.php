<?php

/* BlogBundle:Category:menu.categories.html.twig */
class __TwigTemplate_b3989e5859cc2b28504bc375da86416087e10e3403e05ae53dba26b11236ebe5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bdab71470ec300b5ae5d2756ee70cec795b91c5c03d3bd7a150adede7a0fe7a5 = $this->env->getExtension("native_profiler");
        $__internal_bdab71470ec300b5ae5d2756ee70cec795b91c5c03d3bd7a150adede7a0fe7a5->enter($__internal_bdab71470ec300b5ae5d2756ee70cec795b91c5c03d3bd7a150adede7a0fe7a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "BlogBundle:Category:menu.categories.html.twig"));

        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 2
            echo "    <li><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("blog_read_category", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "</a></li>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_bdab71470ec300b5ae5d2756ee70cec795b91c5c03d3bd7a150adede7a0fe7a5->leave($__internal_bdab71470ec300b5ae5d2756ee70cec795b91c5c03d3bd7a150adede7a0fe7a5_prof);

    }

    public function getTemplateName()
    {
        return "BlogBundle:Category:menu.categories.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 2,  22 => 1,);
    }
}
/* {% for category in categories %}*/
/*     <li><a href="{{path("blog_read_category",{"id":category.id})}}">{{category.name}}</a></li>*/
/* {% endfor %}*/
/* */
