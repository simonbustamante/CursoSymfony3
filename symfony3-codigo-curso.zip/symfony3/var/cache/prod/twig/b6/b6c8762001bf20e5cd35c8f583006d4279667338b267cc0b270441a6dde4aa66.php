<?php

/* BlogBundle::layout.html.twig */
class __TwigTemplate_204ff8ae5022a2d09ab887df2c58f6519fa7984c07b22bb90ec90f2c7d06bf16 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'menu' => array($this, 'block_menu'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_960104ef595dcc815a09486e3e878c45e283053677cd27eadfcca8d204bbb65c = $this->env->getExtension("native_profiler");
        $__internal_960104ef595dcc815a09486e3e878c45e283053677cd27eadfcca8d204bbb65c->enter($__internal_960104ef595dcc815a09486e3e878c45e283053677cd27eadfcca8d204bbb65c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "BlogBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE HTML>
<html lang=\"es\">
    <head>
        <meta charset=\"utf-8\" />
        <title>
            ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "        </title>

        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js\"></script>
        <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" rel=\"stylesheet\" />
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js\"></script>
    </head>
    <body>
        <header>
            <nav class=\"navbar navbar-default\">
                <div class=\"container-fluid\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <a class=\"navbar-brand\" href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("blog_homepage");
        echo "\">Blog Symfony3 !!</a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <ul class=\"nav navbar-nav\">
                            ";
        // line 31
        $this->displayBlock('menu', $context, $blocks);
        // line 35
        echo "                        </ul>
                        
                        <ul class=\"nav navbar-nav navbar-right\">
                            <li><a href=\"#\">
                                ";
        // line 39
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) != null)) {
            // line 40
            echo "                                    Bienvenido, ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "name", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "surname", array()), "html", null, true);
            echo "
                                ";
        }
        // line 42
        echo "                                </a>
                            </li>
                            <li class=\"dropdown\">
                                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\"> <span class=\"glyphicon glyphicon-cog\"></span> <span class=\"caret\"></span></a>
                                <ul class=\"dropdown-menu\">
                                    ";
        // line 47
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) == null)) {
            // line 48
            echo "                                        <li><a href=\"";
            echo $this->env->getExtension('routing')->getPath("login");
            echo "\">Entrar</a></li>
                                    ";
        } else {
            // line 50
            echo "                                        <li><a href=\"";
            echo $this->env->getExtension('routing')->getPath("blog_add_entry");
            echo "\">Añadir entrada</a></li>
                                        <li><a href=\"";
            // line 51
            echo $this->env->getExtension('routing')->getPath("blog_index_tag");
            echo "\">Etiquetas</a></li>
                                        <li><a href=\"";
            // line 52
            echo $this->env->getExtension('routing')->getPath("blog_index_category");
            echo "\">Categorías</a></li>
                                        <li role=\"separator\" class=\"divider\"></li>
                                        <li><a href=\"";
            // line 54
            echo $this->env->getExtension('routing')->getPath("logout");
            echo "\">Salir</a></li>
                                    ";
        }
        // line 56
        echo "                                    <li><a href=\"#\">Ayuda</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container-fluid -->
            </nav>
        </header>
        <section id=\"content\">
            ";
        // line 65
        $this->displayBlock('content', $context, $blocks);
        // line 66
        echo "        </section>
        <footer>
            <hr>
            Curso de Symfony3 - Víctor Robles &copy;
        </footer>
    </body>
</html>
";
        
        $__internal_960104ef595dcc815a09486e3e878c45e283053677cd27eadfcca8d204bbb65c->leave($__internal_960104ef595dcc815a09486e3e878c45e283053677cd27eadfcca8d204bbb65c_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_f59cce30bea5080d88b92c117c19009381a4a2c36e9a2995428c54aada493a35 = $this->env->getExtension("native_profiler");
        $__internal_f59cce30bea5080d88b92c117c19009381a4a2c36e9a2995428c54aada493a35->enter($__internal_f59cce30bea5080d88b92c117c19009381a4a2c36e9a2995428c54aada493a35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Blog con Symfony3 ";
        
        $__internal_f59cce30bea5080d88b92c117c19009381a4a2c36e9a2995428c54aada493a35->leave($__internal_f59cce30bea5080d88b92c117c19009381a4a2c36e9a2995428c54aada493a35_prof);

    }

    // line 31
    public function block_menu($context, array $blocks = array())
    {
        $__internal_63cefcd71010a72d5e0f3e82e17d13e15eb726ee23d2a20e9b4616d83d860214 = $this->env->getExtension("native_profiler");
        $__internal_63cefcd71010a72d5e0f3e82e17d13e15eb726ee23d2a20e9b4616d83d860214->enter($__internal_63cefcd71010a72d5e0f3e82e17d13e15eb726ee23d2a20e9b4616d83d860214_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 32
        echo "                                <li class=\"active\"><a href=\"#\">Link <span class=\"sr-only\">(current)</span></a></li>
                                <li><a href=\"#\">Link</a></li>
                            ";
        
        $__internal_63cefcd71010a72d5e0f3e82e17d13e15eb726ee23d2a20e9b4616d83d860214->leave($__internal_63cefcd71010a72d5e0f3e82e17d13e15eb726ee23d2a20e9b4616d83d860214_prof);

    }

    // line 65
    public function block_content($context, array $blocks = array())
    {
        $__internal_3129ee6cf0ae712741ccc7043fd9ea30cae82d0dd2b3f8344144d6af1925d204 = $this->env->getExtension("native_profiler");
        $__internal_3129ee6cf0ae712741ccc7043fd9ea30cae82d0dd2b3f8344144d6af1925d204->enter($__internal_3129ee6cf0ae712741ccc7043fd9ea30cae82d0dd2b3f8344144d6af1925d204_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        echo " Content default ";
        
        $__internal_3129ee6cf0ae712741ccc7043fd9ea30cae82d0dd2b3f8344144d6af1925d204->leave($__internal_3129ee6cf0ae712741ccc7043fd9ea30cae82d0dd2b3f8344144d6af1925d204_prof);

    }

    public function getTemplateName()
    {
        return "BlogBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 65,  160 => 32,  154 => 31,  142 => 6,  128 => 66,  126 => 65,  115 => 56,  110 => 54,  105 => 52,  101 => 51,  96 => 50,  90 => 48,  88 => 47,  81 => 42,  73 => 40,  71 => 39,  65 => 35,  63 => 31,  54 => 25,  34 => 7,  32 => 6,  25 => 1,);
    }
}
/* <!DOCTYPE HTML>*/
/* <html lang="es">*/
/*     <head>*/
/*         <meta charset="utf-8" />*/
/*         <title>*/
/*             {% block title %} Blog con Symfony3 {% endblock %}*/
/*         </title>*/
/* */
/*         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>*/
/*         <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />*/
/*         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>*/
/*     </head>*/
/*     <body>*/
/*         <header>*/
/*             <nav class="navbar navbar-default">*/
/*                 <div class="container-fluid">*/
/*                     <!-- Brand and toggle get grouped for better mobile display -->*/
/*                     <div class="navbar-header">*/
/*                         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">*/
/*                             <span class="sr-only">Toggle navigation</span>*/
/*                             <span class="icon-bar"></span>*/
/*                             <span class="icon-bar"></span>*/
/*                             <span class="icon-bar"></span>*/
/*                         </button>*/
/*                         <a class="navbar-brand" href="{{path("blog_homepage")}}">Blog Symfony3 !!</a>*/
/*                     </div>*/
/* */
/*                     <!-- Collect the nav links, forms, and other content for toggling -->*/
/*                     <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">*/
/*                         <ul class="nav navbar-nav">*/
/*                             {% block menu %}*/
/*                                 <li class="active"><a href="#">Link <span class="sr-only">(current)</span></a></li>*/
/*                                 <li><a href="#">Link</a></li>*/
/*                             {% endblock %}*/
/*                         </ul>*/
/*                         */
/*                         <ul class="nav navbar-nav navbar-right">*/
/*                             <li><a href="#">*/
/*                                 {% if app.user != null%}*/
/*                                     Bienvenido, {{app.user.name}} {{app.user.surname}}*/
/*                                 {% endif%}*/
/*                                 </a>*/
/*                             </li>*/
/*                             <li class="dropdown">*/
/*                                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <span class="glyphicon glyphicon-cog"></span> <span class="caret"></span></a>*/
/*                                 <ul class="dropdown-menu">*/
/*                                     {% if app.user == null%}*/
/*                                         <li><a href="{{path("login")}}">Entrar</a></li>*/
/*                                     {%else%}*/
/*                                         <li><a href="{{path("blog_add_entry")}}">Añadir entrada</a></li>*/
/*                                         <li><a href="{{path("blog_index_tag")}}">Etiquetas</a></li>*/
/*                                         <li><a href="{{path("blog_index_category")}}">Categorías</a></li>*/
/*                                         <li role="separator" class="divider"></li>*/
/*                                         <li><a href="{{path("logout")}}">Salir</a></li>*/
/*                                     {% endif%}*/
/*                                     <li><a href="#">Ayuda</a></li>*/
/*                                 </ul>*/
/*                             </li>*/
/*                         </ul>*/
/*                     </div><!-- /.navbar-collapse -->*/
/*                 </div><!-- /.container-fluid -->*/
/*             </nav>*/
/*         </header>*/
/*         <section id="content">*/
/*             {% block content %} Content default {% endblock %}*/
/*         </section>*/
/*         <footer>*/
/*             <hr>*/
/*             Curso de Symfony3 - Víctor Robles &copy;*/
/*         </footer>*/
/*     </body>*/
/* </html>*/
/* */
