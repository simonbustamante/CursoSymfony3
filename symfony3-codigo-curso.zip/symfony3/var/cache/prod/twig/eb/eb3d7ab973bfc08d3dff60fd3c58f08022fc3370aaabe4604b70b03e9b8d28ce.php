<?php

/* BlogBundle:User:login.html.twig */
class __TwigTemplate_f0accbb733eba59d29321c335ba3663045fd96d9f32d1c346b51af66144cd9e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("BlogBundle::layout.html.twig", "BlogBundle:User:login.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "BlogBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff50c76384d186d64b80ab3b55eb828256caceffd83227740d974f5202d0ed7d = $this->env->getExtension("native_profiler");
        $__internal_ff50c76384d186d64b80ab3b55eb828256caceffd83227740d974f5202d0ed7d->enter($__internal_ff50c76384d186d64b80ab3b55eb828256caceffd83227740d974f5202d0ed7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "BlogBundle:User:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ff50c76384d186d64b80ab3b55eb828256caceffd83227740d974f5202d0ed7d->leave($__internal_ff50c76384d186d64b80ab3b55eb828256caceffd83227740d974f5202d0ed7d_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_b7a2983904646a13961f22cf160bb89dad272bc2055bd0ce21f5d09a6f8494bb = $this->env->getExtension("native_profiler");
        $__internal_b7a2983904646a13961f22cf160bb89dad272bc2055bd0ce21f5d09a6f8494bb->enter($__internal_b7a2983904646a13961f22cf160bb89dad272bc2055bd0ce21f5d09a6f8494bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "
    ";
        // line 4
        if ($this->env->getExtension('security')->isGranted("ROLE_USER")) {
            // line 5
            echo "        <strong>
            Estas logueado como usuario normal
        </strong>
    ";
        }
        // line 9
        echo "    
    ";
        // line 10
        if ($this->env->getExtension('security')->isGranted("ROLE_ADMIN")) {
            // line 11
            echo "        <strong>
            Estas logueado como usuario ADMINISTRADOR TODOPODEROSO
        </strong>
    ";
        }
        // line 15
        echo "    
    <div class=\"col-lg-4\">
        <h2>Identifícate</h2>
        <hr/>
        <form action=\"";
        // line 19
        echo $this->env->getExtension('routing')->getPath("login_check");
        echo "\" method=\"post\">
            <label>Email:</label>
            <input type=\"email\" id=\"username\" name=\"_username\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" class=\"form-control\" />
            <br/>
            <label>Contraseña:</label>
            <input type=\"password\" id=\"password\" name=\"_password\" class=\"form-control\" />
            <br/>
            <input type=\"submit\" value=\"Entrar\" class=\"btn btn-success\"/>
            <input type=\"hidden\" name=\"_target_path\" value=\"/login\" />
        </form>
    </div>
            
    <div class=\"col-lg-4\">
        <h2>Registrate</h2>
        <hr/>
        ";
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array(), "method"), "get", array(0 => "status"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 35
            echo "            <div class=\"alert alert-success\">";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "        ";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("action" => "", "method" => "POST"));
        echo "
        ";
        // line 38
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
    
    <div class=\"clearfix\"></div>
";
        
        $__internal_b7a2983904646a13961f22cf160bb89dad272bc2055bd0ce21f5d09a6f8494bb->leave($__internal_b7a2983904646a13961f22cf160bb89dad272bc2055bd0ce21f5d09a6f8494bb_prof);

    }

    public function getTemplateName()
    {
        return "BlogBundle:User:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 38,  102 => 37,  93 => 35,  89 => 34,  73 => 21,  68 => 19,  62 => 15,  56 => 11,  54 => 10,  51 => 9,  45 => 5,  43 => 4,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends "BlogBundle::layout.html.twig"%}*/
/* {% block content %}*/
/* */
/*     {% if is_granted('ROLE_USER') %}*/
/*         <strong>*/
/*             Estas logueado como usuario normal*/
/*         </strong>*/
/*     {% endif %}*/
/*     */
/*     {% if is_granted('ROLE_ADMIN') %}*/
/*         <strong>*/
/*             Estas logueado como usuario ADMINISTRADOR TODOPODEROSO*/
/*         </strong>*/
/*     {% endif %}*/
/*     */
/*     <div class="col-lg-4">*/
/*         <h2>Identifícate</h2>*/
/*         <hr/>*/
/*         <form action="{{path("login_check")}}" method="post">*/
/*             <label>Email:</label>*/
/*             <input type="email" id="username" name="_username" value="{{ last_username }}" class="form-control" />*/
/*             <br/>*/
/*             <label>Contraseña:</label>*/
/*             <input type="password" id="password" name="_password" class="form-control" />*/
/*             <br/>*/
/*             <input type="submit" value="Entrar" class="btn btn-success"/>*/
/*             <input type="hidden" name="_target_path" value="/login" />*/
/*         </form>*/
/*     </div>*/
/*             */
/*     <div class="col-lg-4">*/
/*         <h2>Registrate</h2>*/
/*         <hr/>*/
/*         {% for message in app.session.flashbag().get('status') %}*/
/*             <div class="alert alert-success">{{ message }}</div>*/
/*         {% endfor %}*/
/*         {{form_start(form, {'action':'', 'method':'POST'})}}*/
/*         {{form_end(form)}}*/
/*     </div>*/
/*     */
/*     <div class="clearfix"></div>*/
/* {% endblock %}*/
