<?php

/* BlogBundle:Entry:index.html.twig */
class __TwigTemplate_47ebe7244bdfc9484c9031ae599663192166b89c2755e8dd925194e46c2b9974 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("BlogBundle::layout.html.twig", "BlogBundle:Entry:index.html.twig", 1);
        $this->blocks = array(
            'menu' => array($this, 'block_menu'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "BlogBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68660146095e3c2251f8b25995bff6e704649f01c7a7035fc99317f2928a8643 = $this->env->getExtension("native_profiler");
        $__internal_68660146095e3c2251f8b25995bff6e704649f01c7a7035fc99317f2928a8643->enter($__internal_68660146095e3c2251f8b25995bff6e704649f01c7a7035fc99317f2928a8643_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "BlogBundle:Entry:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_68660146095e3c2251f8b25995bff6e704649f01c7a7035fc99317f2928a8643->leave($__internal_68660146095e3c2251f8b25995bff6e704649f01c7a7035fc99317f2928a8643_prof);

    }

    // line 3
    public function block_menu($context, array $blocks = array())
    {
        $__internal_32647ed934b85dd6f1c20af90f306693a272077c89215965241ae90907686aae = $this->env->getExtension("native_profiler");
        $__internal_32647ed934b85dd6f1c20af90f306693a272077c89215965241ae90907686aae->enter($__internal_32647ed934b85dd6f1c20af90f306693a272077c89215965241ae90907686aae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 4
        echo "    ";
        $this->loadTemplate("BlogBundle:Category:menu.categories.html.twig", "BlogBundle:Entry:index.html.twig", 4)->display(array_merge($context, array("categories" => (isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")))));
        
        $__internal_32647ed934b85dd6f1c20af90f306693a272077c89215965241ae90907686aae->leave($__internal_32647ed934b85dd6f1c20af90f306693a272077c89215965241ae90907686aae_prof);

    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        $__internal_90adea5d56ecc8dc509c6e79624fc0195b53abaca2d8424b0c54e1c8d831a6f7 = $this->env->getExtension("native_profiler");
        $__internal_90adea5d56ecc8dc509c6e79624fc0195b53abaca2d8424b0c54e1c8d831a6f7->enter($__internal_90adea5d56ecc8dc509c6e79624fc0195b53abaca2d8424b0c54e1c8d831a6f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "
";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array(), "method"), "get", array(0 => "status"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 10
            echo "    <div class=\"alert alert-success\">";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "
";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entries"]) ? $context["entries"] : $this->getContext($context, "entries")));
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 14
            echo "    <div class=\"col-lg-11\">
        <p class=\"pull-left\" style=\"margin-right:20px;\"><img width=\"200\" src=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl(("uploads/" . $this->getAttribute($context["entry"], "image", array()))), "html", null, true);
            echo "\"/></p>
        <p><strong>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["entry"], "title", array()), "html", null, true);
            echo "</strong></p>
        <p>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["entry"], "category", array()), "name", array()), "html", null, true);
            echo "</p>
        <p>Autor:";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["entry"], "user", array()), "name", array()), "html", null, true);
            echo "</p>
        
        <p>
            ";
            // line 21
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["entry"], "entryTag", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["et"]) {
                // line 22
                echo "                ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["et"], "tag", array()), "name", array()), "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['et'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 24
            echo "        </p>
        
        ";
            // line 26
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array(), "any", false, true), "id", array(), "any", true, true) && ($this->getAttribute($this->getAttribute($context["entry"], "user", array()), "id", array()) == $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array())))) {
                // line 27
                echo "        <p>
            <a href=\"";
                // line 28
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("blog_delete_entry", array("id" => $this->getAttribute($context["entry"], "id", array()))), "html", null, true);
                echo "\" class=\"btn btn-danger\">Eliminar</a>
            <a href=\"";
                // line 29
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("blog_edit_entry", array("id" => $this->getAttribute($context["entry"], "id", array()))), "html", null, true);
                echo "\" class=\"btn btn-warning\">";
                echo $this->env->getExtension('translator')->getTranslator()->trans("btn_edit", array(), "messages");
                echo "</a>
        </p>
        ";
            }
            // line 32
            echo "        
        <div class=\"clearfix\"></div>
        <hr/>
    </div>
    
    <div class=\"clearfix\"></div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "
<ul class=\"pagination\">
    ";
        // line 41
        if (((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")) == 1)) {
            // line 42
            echo "        
    ";
        } else {
            // line 44
            echo "      ";
            $context["page"] = ((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")) - 1);
            // line 45
            echo "    ";
        }
        // line 46
        echo "    
    <li><a href=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("blog_homepage", array("page" => (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")))), "html", null, true);
        echo "\">&laquo;</a></li>
    ";
        // line 48
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["pagesCount"]) ? $context["pagesCount"] : $this->getContext($context, "pagesCount"))));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 49
            echo "        <li><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("blog_homepage", array("page" => $context["i"])), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "</a></li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "    
    ";
        // line 52
        if (((isset($context["page_m"]) ? $context["page_m"] : $this->getContext($context, "page_m")) == (isset($context["pagesCount"]) ? $context["pagesCount"] : $this->getContext($context, "pagesCount")))) {
            // line 53
            echo "        
    ";
        } else {
            // line 55
            echo "      ";
            $context["page_m"] = ((isset($context["page_m"]) ? $context["page_m"] : $this->getContext($context, "page_m")) + 1);
            // line 56
            echo "    ";
        }
        // line 57
        echo "    <li><a href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("blog_homepage", array("page" => (isset($context["page_m"]) ? $context["page_m"] : $this->getContext($context, "page_m")))), "html", null, true);
        echo "\">&raquo;</a></li>
</ul>

";
        
        $__internal_90adea5d56ecc8dc509c6e79624fc0195b53abaca2d8424b0c54e1c8d831a6f7->leave($__internal_90adea5d56ecc8dc509c6e79624fc0195b53abaca2d8424b0c54e1c8d831a6f7_prof);

    }

    public function getTemplateName()
    {
        return "BlogBundle:Entry:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  198 => 57,  195 => 56,  192 => 55,  188 => 53,  186 => 52,  183 => 51,  172 => 49,  168 => 48,  164 => 47,  161 => 46,  158 => 45,  155 => 44,  151 => 42,  149 => 41,  145 => 39,  133 => 32,  125 => 29,  121 => 28,  118 => 27,  116 => 26,  112 => 24,  103 => 22,  99 => 21,  93 => 18,  89 => 17,  85 => 16,  81 => 15,  78 => 14,  74 => 13,  71 => 12,  62 => 10,  58 => 9,  55 => 8,  49 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends "BlogBundle::layout.html.twig" %}*/
/* */
/* {% block menu %}*/
/*     {% include "BlogBundle:Category:menu.categories.html.twig" with {'categories': categories}  %}*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/* */
/* {% for message in app.session.flashbag().get('status') %}*/
/*     <div class="alert alert-success">{{ message }}</div>*/
/* {% endfor %}*/
/* */
/* {% for entry in entries %}*/
/*     <div class="col-lg-11">*/
/*         <p class="pull-left" style="margin-right:20px;"><img width="200" src="{{ asset("uploads/"~entry.image)}}"/></p>*/
/*         <p><strong>{{entry.title}}</strong></p>*/
/*         <p>{{entry.category.name}}</p>*/
/*         <p>Autor:{{entry.user.name}}</p>*/
/*         */
/*         <p>*/
/*             {% for et in entry.entryTag %}*/
/*                 {{et.tag.name}}*/
/*             {% endfor %}*/
/*         </p>*/
/*         */
/*         {%if (app.user.id is defined) and (entry.user.id == app.user.id) %}*/
/*         <p>*/
/*             <a href="{{path("blog_delete_entry",{"id":entry.id})}}" class="btn btn-danger">Eliminar</a>*/
/*             <a href="{{path("blog_edit_entry",{"id":entry.id})}}" class="btn btn-warning">{% trans %}btn_edit{% endtrans %}</a>*/
/*         </p>*/
/*         {%endif%}*/
/*         */
/*         <div class="clearfix"></div>*/
/*         <hr/>*/
/*     </div>*/
/*     */
/*     <div class="clearfix"></div>*/
/* {% endfor %}*/
/* */
/* <ul class="pagination">*/
/*     {% if(page==1)%}*/
/*         */
/*     {%else%}*/
/*       {% set page = page-1 %}*/
/*     {%endif%}*/
/*     */
/*     <li><a href="{{ path('blog_homepage', {"page":page}) }}">&laquo;</a></li>*/
/*     {% for i in 1..pagesCount %}*/
/*         <li><a href="{{ path('blog_homepage', {"page":i}) }}">{{i}}</a></li>*/
/*     {% endfor %}*/
/*     */
/*     {% if(page_m==pagesCount)%}*/
/*         */
/*     {%else%}*/
/*       {% set page_m = page_m+1 %}*/
/*     {%endif%}*/
/*     <li><a href="{{ path('blog_homepage', {"page":page_m}) }}">&raquo;</a></li>*/
/* </ul>*/
/* */
/* {% endblock %}*/
